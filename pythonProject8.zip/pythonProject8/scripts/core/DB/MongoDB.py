from pydantic import BaseModel
from pymongo import MongoClient

# import mongo client to connect
# create function for db connection
# Creating instance of mongo client
client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
# Creating database
db = client.interns_b2_23

# # Creating document
lib = db.Madhvi_lib


# # Inserting data
class Book(BaseModel):
    id: int
    title: str
    author: str
    borrowed: bool





def get_all_data():
    books = lib.find({})
    details = []
    for book in books:
        detail = {'id': book['id'], 'title': book['title'], 'author': book['author'], 'borrowed': book['borrowed']}
        details.append(detail)
    return {"details": details}


def get_book_id(id: int):
    books = lib.find({})
    details = []
    for book in books:
        if book['id'] == id:
            detail = {'id': book['id'], 'title': book['title'], 'author': book['author'], 'borrowed': book['borrowed']}
            details.append(detail)
    return {"details": details}


def create_book(book: Book):
    lib.insert_one(book.dict())
    return {"message": "Book created successfully"}


def update_book(book_id: int, book: Book):
    lib.update_one({"id": book_id}, {"$set": book})
    return {"message": "Book updated successfully"}

def delete_book(book_id: int):
    result = lib.delete_one({"id": book_id})

    if result.deleted_count > 0:
        return {"message": "Book deleted successfully"}
    else:
        return {"error": "Book not found"}
