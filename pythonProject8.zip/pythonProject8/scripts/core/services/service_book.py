from fastapi import APIRouter
from scripts.core.DB.MongoDB import Book
from scripts.core.handlers.book_handler import Book_handler

book_router = APIRouter()
book_object = Book_handler()


@book_router.get("/")
def get_all_data():
    all_book = book_object.get_data()
    return all_book


@book_router.get("/book_based_on_id/{id}")
def get_data(id: int):
    Id_book = book_object.get_data(id)
    return Id_book


@book_router.post("/books/")
def create_data(book: Book):
    all_book = book_object.create_data(book)
    return all_book


@book_router.put("/books/{book_id}")
def update_data(book: Book, book_id: int):
    all_book = book_object.update_data(book_id, book)
    return book_id


@book_router.delete("/books/{book_id}")
def get_data(book_id: int):
    book_object = Book_handler()
    all_book = book_object.delete_data()
    return all_book
