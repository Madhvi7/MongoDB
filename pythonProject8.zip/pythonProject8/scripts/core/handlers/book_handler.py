from scripts.core.DB.MongoDB import get_all_data, get_book_id, create_book, update_book, delete_book, Book


class Book_handler():
    def get_data(self):
        return get_all_data()

    def get1_data(self):
        return get_book_id()

    def create_data(self, book: Book):
        return create_book(book)

    def delete_data(self, id: int):
        return delete_book(id)

    def update_data(self, id: int, book: Book):
        print(id,book)
        return update_book(id, book)
