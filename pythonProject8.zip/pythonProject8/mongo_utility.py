from pymongo import MongoClient  # import mongo client to connect
# Creating instance of mongo client
class Item():
    def insert(self):
client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
# Creating database
db = client.interns_b2_23
inventory_item = {"id": "201941047",
                  "name": "Blanket",
                  "quantity": "7",
                  "cost": "1599"
                  }
# # Creating document
inventory = db.Madhvi_inventory
# # Inserting data
inventory.insert_one(inventory_item)
# # Fetching data
print(list(inventory.find({"id": "201941047"})))

